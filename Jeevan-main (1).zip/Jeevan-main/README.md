# Jeevan

The project involves creating a website for the people of India who needs financial support for their medical treatment. Every year the people have to go through different types of medical treatment, for that they face 
difficulties in arranging the money for they medical treatments. Specially the backward and poor people, this is a major problem as they do not know anything about the government facilities and NGO’s.

My role : Performed Wet Application Penetration Testing on the website and worked on database (MySQL)
